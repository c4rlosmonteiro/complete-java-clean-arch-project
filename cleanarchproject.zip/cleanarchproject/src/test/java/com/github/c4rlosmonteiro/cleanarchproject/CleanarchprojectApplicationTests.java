package com.github.c4rlosmonteiro.cleanarchproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CleanarchprojectApplicationTests {

	@Test
	void contextLoads() {
	}

}
